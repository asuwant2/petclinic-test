﻿window.SEIBRO_DATA=[
    {
        "ExcelRow":  3,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합채권형",
        "FundName":  "미래에셋개인연금고배당포커스30증권전환형자투자신탁 1(채권혼합)",
        "SearchTerm":  "미래에셋개인연금고배당포커스30",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금고배당포커스30증권전환형자투자신탁1호(채권혼합)",
        "SeibroIsin":  "KRZ502020830",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "27.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "50.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "3.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "24.31"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "16.67"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "대한유화",
                             "Weight":  "4.33"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "JB금융지주",
                             "Weight":  "3.36"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "신세계",
                             "Weight":  "2.98"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02250-2806(25-4)",
                             "Weight":  "13.39"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "기업은행(신)2509할1A-18",
                             "Weight":  "11.23"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-2706(24-4)",
                             "Weight":  "10.36"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "기업은행(신)2411이1.5A-20",
                             "Weight":  "9.14"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2712(24-12)",
                             "Weight":  "9.11"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "CB",
                      "StockStyleLabel":  "멀티형/혼합형",
                      "PER":  "6.04",
                      "PBR":  "1.32",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.19"
                  }
    },
    {
        "ExcelRow":  4,
        "Company":  "미래에셋자산운용",
        "Type":  "주식형",
        "FundName":  "미래에셋개인연금고배당포커스증권전환형자투자신탁 1(주식)",
        "SearchTerm":  "미래에셋개인연금고배당포커스",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금고배당포커스증권전환형자투자신탁1호(주식)",
        "SeibroIsin":  "KRZ502020870",
        "Score":  1.3,
        "SecondName":  "미래에셋개인연금고배당포커스30증권전환형자투자신탁1호(채권혼합)",
        "SecondScore":  0.5343,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "97.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "24.31"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "16.67"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "대한유화",
                             "Weight":  "4.33"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "JB금융지주",
                             "Weight":  "3.36"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "신세계",
                             "Weight":  "2.98"
                         }
                     ],
        "CandidateCount":  2,
        "Style":  {
                      "StockStyleCode":  "CB",
                      "StockStyleLabel":  "멀티형/혼합형",
                      "PER":  "6.04",
                      "PBR":  "1.32",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  5,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합채권형",
        "FundName":  "미래에셋개인연금글로벌그레이트컨슈머30증권전환형자투자신탁 1(채권혼합)",
        "SearchTerm":  "미래에셋개인연금글로벌그레이트컨슈머30",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금글로벌그레이트컨슈머30증권전환형자투자신탁1호(채권혼합)",
        "SeibroIsin":  "KRZ501874360",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "12.00",
                           "DomesticBond":  "7.00",
                           "OverseasBond":  "19.00",
                           "Fund":  "12.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "BYD Co Ltd",
                             "Weight":  "11.10"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Amazon.com Inc",
                             "Weight":  "9.77"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "NVIDIA Corp",
                             "Weight":  "7.12"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Eli Lilly \u0026 Co",
                             "Weight":  "6.73"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Madrigal Pharmaceuticals Inc",
                             "Weight":  "6.65"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "10.67"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 3 1/2 01/31/28",
                             "Weight":  "8.74"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 4 1/4 05/15/35",
                             "Weight":  "8.52"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 4 11/15/35",
                             "Weight":  "4.55"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03000-2909(24-7)",
                             "Weight":  "3.89"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "7.14"
                  }
    },
    {
        "ExcelRow":  6,
        "Company":  "미래에셋자산운용",
        "Type":  "주식형",
        "FundName":  "미래에셋개인연금글로벌그레이트컨슈머증권전환형자투자신탁 1(주식)",
        "SearchTerm":  "미래에셋개인연금글로벌그레이트컨슈머",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금글로벌그레이트컨슈머증권전환형자투자신탁1호(주식)",
        "SeibroIsin":  "KRZ501844840",
        "Score":  1.3,
        "SecondName":  "미래에셋개인연금글로벌그레이트컨슈머30증권전환형자투자신탁1호(채권혼합)",
        "SecondScore":  0.58,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "43.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "8.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "BYD Co Ltd",
                             "Weight":  "11.10"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Amazon.com Inc",
                             "Weight":  "9.77"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "NVIDIA Corp",
                             "Weight":  "7.12"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Eli Lilly \u0026 Co",
                             "Weight":  "6.73"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Madrigal Pharmaceuticals Inc",
                             "Weight":  "6.65"
                         }
                     ],
        "CandidateCount":  2,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  7,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합채권형",
        "FundName":  "미래에셋개인연금글로벌그로스40증권전환형자투자신탁 1(채권혼합)",
        "SearchTerm":  "미래에셋개인연금글로벌그로스40",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금글로벌그로스40증권전환형자투자신탁1호(채권혼합)",
        "SeibroIsin":  "KRZ502020840",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "19.00",
                           "DomesticBond":  "4.00",
                           "OverseasBond":  "20.00",
                           "Fund":  "6.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "NVIDIA Corp",
                             "Weight":  "8.50"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Taiwan Semiconductor Manufacturing Co Ltd",
                             "Weight":  "6.02"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Broadcom Inc",
                             "Weight":  "5.63"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Alphabet Inc",
                             "Weight":  "5.41"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Siemens Energy AG",
                             "Weight":  "4.89"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 3 1/2 01/31/28",
                             "Weight":  "9.26"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "6.30"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 3 1/2 10/31/27",
                             "Weight":  "4.36"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 4 1/4 05/15/35",
                             "Weight":  "4.05"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 4 11/15/35",
                             "Weight":  "3.29"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "5.53"
                  }
    },
    {
        "ExcelRow":  8,
        "Company":  "미래에셋자산운용",
        "Type":  "주식형",
        "FundName":  "미래에셋개인연금글로벌그로스증권전환형자투자신탁 1(주식)",
        "SearchTerm":  "미래에셋개인연금글로벌그로스",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금글로벌그로스증권전환형자투자신탁1호(주식)",
        "SeibroIsin":  "KRZ502020850",
        "Score":  1.3,
        "SecondName":  "미래에셋개인연금글로벌그로스40증권전환형자투자신탁1호(채권혼합)",
        "SecondScore":  0.5343,
        "AsOf":  "",
        "Allocation":  {
                           "DomesticStock":  "",
                           "OverseasStock":  "",
                           "DomesticBond":  "",
                           "OverseasBond":  "",
                           "Fund":  ""
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "NVIDIA Corp",
                             "Weight":  "8.50"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Taiwan Semiconductor Manufacturing Co Ltd",
                             "Weight":  "6.02"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Broadcom Inc",
                             "Weight":  "5.63"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Alphabet Inc",
                             "Weight":  "5.41"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Siemens Energy AG",
                             "Weight":  "4.89"
                         }
                     ],
        "CandidateCount":  2,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  9,
        "Company":  "미래에셋자산운용",
        "Type":  "채권형",
        "FundName":  "미래에셋개인연금글로벌다이나믹증권전환형자투자신탁 1(채권)",
        "SearchTerm":  "미래에셋개인연금글로벌다이나믹",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금글로벌다이나믹증권전환형자투자신탁1호(채권)",
        "SeibroIsin":  "KRZ501777450",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "6.00",
                           "OverseasBond":  "33.00",
                           "Fund":  "7.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "T 3 1/2 01/31/28",
                             "Weight":  "9.26"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "6.30"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 3 1/2 10/31/27",
                             "Weight":  "4.36"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 4 1/4 05/15/35",
                             "Weight":  "4.05"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 4 11/15/35",
                             "Weight":  "3.29"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "5.53"
                  }
    },
    {
        "ExcelRow":  10,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합채권형",
        "FundName":  "미래에셋개인연금글로벌배당과인컴증권전환형자투자신탁 1(채권혼합)",
        "SearchTerm":  "미래에셋개인연금글로벌배당과인컴",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금글로벌배당과인컴증권전환형자투자신탁1호(채권혼합)",
        "SeibroIsin":  "KRZ501934670",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "1.00",
                           "OverseasStock":  "19.00",
                           "DomesticBond":  "5.00",
                           "OverseasBond":  "14.00",
                           "Fund":  "10.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "NVIDIA Corp",
                             "Weight":  "4.91"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Apple Inc",
                             "Weight":  "4.14"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Broadcom Inc",
                             "Weight":  "4.02"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Taiwan Semiconductor Manufacturing Co Ltd",
                             "Weight":  "3.91"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Alphabet Inc",
                             "Weight":  "3.16"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "10.50"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 3 1/2 01/31/28",
                             "Weight":  "8.60"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 4 1/4 05/15/35",
                             "Weight":  "8.39"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 4 11/15/35",
                             "Weight":  "4.47"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03000-2909(24-7)",
                             "Weight":  "3.83"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "11.70",
                      "PBR":  "2.73",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "7.04"
                  }
    },
    {
        "ExcelRow":  11,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합주식형",
        "FundName":  "미래에셋개인연금글로벌배당커버드콜액티브증권전환형자투자신탁 1(주식혼합)",
        "SearchTerm":  "미래에셋개인연금글로벌배당커버드콜액티브",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금글로벌배당커버드콜액티브증권전환형자투자신탁1호(주식혼합)",
        "SeibroIsin":  "KRZ501934680",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "3.00",
                           "OverseasStock":  "41.00",
                           "DomesticBond":  "1.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "6.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "NVIDIA Corp",
                             "Weight":  "4.91"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Apple Inc",
                             "Weight":  "4.14"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Broadcom Inc",
                             "Weight":  "4.02"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Taiwan Semiconductor Manufacturing Co Ltd",
                             "Weight":  "3.91"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Alphabet Inc",
                             "Weight":  "3.16"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "통안02280-2607-01",
                             "Weight":  "68.24"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "31.76"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "11.70",
                      "PBR":  "2.73",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "0.91"
                  }
    },
    {
        "ExcelRow":  12,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합채권형",
        "FundName":  "미래에셋개인연금글로벌인컴증권전환형자투자신탁 1(채권혼합)",
        "SearchTerm":  "미래에셋개인연금글로벌인컴",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금글로벌인컴증권전환형자투자신탁1호(채권혼합)",
        "SeibroIsin":  "KRZ501837110",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "2.00",
                           "OverseasStock":  "15.00",
                           "DomesticBond":  "9.00",
                           "OverseasBond":  "21.00",
                           "Fund":  "9.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "Broadcom Inc",
                             "Weight":  "3.63"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Apple Inc",
                             "Weight":  "3.09"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Microsoft Corp",
                             "Weight":  "2.69"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Alphabet Inc",
                             "Weight":  "2.65"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Williams Cos Inc/The",
                             "Weight":  "2.29"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03000-2803(26-1)",
                             "Weight":  "13.96"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-3512(25-11)",
                             "Weight":  "13.46"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "B 05/26/26",
                             "Weight":  "10.37"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 3 7/8 07/31/30",
                             "Weight":  "10.33"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "HIGHWY 5 05/14/27 REGS",
                             "Weight":  "5.24"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "MH",
                      "BondStyleLabel":  "고등급/중기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "2.83"
                  }
    },
    {
        "ExcelRow":  13,
        "Company":  "미래에셋자산운용",
        "Type":  "주식형",
        "FundName":  "미래에셋개인연금글로벌헬스케어증권전환형자투자신탁 1(주식)",
        "SearchTerm":  "미래에셋개인연금글로벌헬스케어",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금글로벌헬스케어증권전환형자투자신탁1호(주식)",
        "SeibroIsin":  "KRZ502020860",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "49.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "Eli Lilly \u0026 Co",
                             "Weight":  "9.47"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "AstraZeneca PLC",
                             "Weight":  "6.18"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "UnitedHealth Group Inc",
                             "Weight":  "5.35"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Lonza Group AG",
                             "Weight":  "5.13"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Intuitive Surgical Inc",
                             "Weight":  "4.93"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  14,
        "Company":  "미래에셋자산운용",
        "Type":  "채권형",
        "FundName":  "미래에셋개인연금단기증권전환형자투자신탁 1(채권)",
        "SearchTerm":  "미래에셋개인연금단기",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금단기증권전환형자투자신탁1호(채권)",
        "SeibroIsin":  "KRZ501844850",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "65.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "3.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2712(24-12)",
                             "Weight":  "12.71"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-2706(24-4)",
                             "Weight":  "8.57"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국수출입금융2604하-할인-122",
                             "Weight":  "6.28"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "산금24신이0200-0805-1",
                             "Weight":  "4.26"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "기업은행(신)2411이1.5A-20",
                             "Weight":  "4.25"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "0.95"
                  }
    },
    {
        "ExcelRow":  15,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합채권형",
        "FundName":  "미래에셋개인연금배당과인컴증권전환형자투자신탁 1(채권혼합)",
        "SearchTerm":  "미래에셋개인연금배당과인컴",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금배당과인컴증권전환형자투자신탁1호(채권혼합)",
        "SeibroIsin":  "KRZ501934700",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "38.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "5.00",
                           "OverseasBond":  "14.00",
                           "Fund":  "14.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "19.84"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "19.24"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자우",
                             "Weight":  "10.93"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK스퀘어",
                             "Weight":  "1.97"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "KB금융",
                             "Weight":  "1.69"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "10.67"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 3 1/2 01/31/28",
                             "Weight":  "8.74"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 4 1/4 05/15/35",
                             "Weight":  "8.52"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 4 11/15/35",
                             "Weight":  "4.55"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03000-2909(24-7)",
                             "Weight":  "3.89"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "6.34",
                      "PBR":  "1.87",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "7.14"
                  }
    },
    {
        "ExcelRow":  16,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합주식형",
        "FundName":  "미래에셋개인연금배당커버드콜액티브증권전환형자투자신탁 1(주식혼합)",
        "SearchTerm":  "미래에셋개인연금배당커버드콜액티브",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금배당커버드콜액티브증권전환형자투자신탁1호(주식혼합)",
        "SeibroIsin":  "KRZ501874370",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "80.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "13.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "19.84"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "19.24"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자우",
                             "Weight":  "10.93"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK스퀘어",
                             "Weight":  "1.97"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "KB금융",
                             "Weight":  "1.69"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "6.34",
                      "PBR":  "1.87",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  17,
        "Company":  "미래에셋자산운용",
        "Type":  "주식형",
        "FundName":  "미래에셋개인연금소비성장증권전환형자투자신탁 1(주식)",
        "SearchTerm":  "미래에셋개인연금소비성장",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금소비성장증권전환형자투자신탁1호(주식)",
        "SeibroIsin":  "KRZ502020880",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "92.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "2.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "25.37"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "15.23"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전기",
                             "Weight":  "5.64"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "에이피알",
                             "Weight":  "3.19"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "한국콜마",
                             "Weight":  "3.07"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "CG",
                      "StockStyleLabel":  "멀티형/성장형",
                      "PER":  "7.87",
                      "PBR":  "2.26",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  18,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합채권형",
        "FundName":  "미래에셋개인연금스마트롱숏30증권전환형자투자신탁 1(채권혼합)",
        "SearchTerm":  "미래에셋개인연금스마트롱숏30",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금스마트롱숏30증권전환형자투자신탁1호(채권혼합)",
        "SeibroIsin":  "KRZ501887520",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  {
                           "DomesticStock":  "",
                           "OverseasStock":  "",
                           "DomesticBond":  "",
                           "OverseasBond":  "",
                           "Fund":  ""
                       },
        "Holdings":  [

                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  19,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합주식형",
        "FundName":  "미래에셋개인연금스마트롱숏50증권전환형자투자신탁 1(주식혼합)",
        "SearchTerm":  "미래에셋개인연금스마트롱숏50",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금스마트롱숏50증권전환형자투자신탁1호(주식혼합)",
        "SeibroIsin":  "KRZ501887510",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "47.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "14.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "2.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "23.07"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "21.86"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전기",
                             "Weight":  "5.06"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "두산퓨얼셀",
                             "Weight":  "3.12"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성SDI",
                             "Weight":  "2.92"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "농금채(중앙회)2024-10이2Y-C",
                             "Weight":  "22.59"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "통안03420-2804-02",
                             "Weight":  "18.81"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02250-2806(25-4)",
                             "Weight":  "15.88"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국전력1445",
                             "Weight":  "7.60"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "인천항만공사17",
                             "Weight":  "7.56"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "8.01",
                      "PBR":  "2.49",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.26"
                  }
    },
    {
        "ExcelRow":  20,
        "Company":  "미래에셋자산운용",
        "Type":  "재간접형",
        "FundName":  "미래에셋개인연금아시아그레이트컨슈머증권전환형자투자신탁 1(주식-재간접형)",
        "SearchTerm":  "미래에셋개인연금아시아그레이트컨슈머",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금아시아그레이트컨슈머증권전환형자투자신탁1호(주식-재간접형)",
        "SeibroIsin":  "KRZ501887530",
        "Score":  1.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "96.00"
                       },
        "Holdings":  [

                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  21,
        "Company":  "미래에셋자산운용",
        "Type":  "주식형",
        "FundName":  "미래에셋개인연금증권전환형자투자신탁 1[주식]",
        "SearchTerm":  "미래에셋개인연금",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금증권전환형자투자신탁1호(주식)",
        "SeibroIsin":  "KRZ501698630",
        "Score":  1.3,
        "SecondName":  "미래에셋개인연금증권전환형자투자신탁1호 (주식혼합)",
        "SecondScore":  1.0262,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "89.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "25.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "17.12"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "두산에너빌리티",
                             "Weight":  "3.54"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK스퀘어",
                             "Weight":  "2.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "현대차",
                             "Weight":  "2.32"
                         }
                     ],
        "CandidateCount":  26,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "7.03",
                      "PBR":  "1.68",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  22,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합주식형",
        "FundName":  "미래에셋개인연금증권전환형자투자신탁 1[주식혼합]",
        "SearchTerm":  "미래에셋개인연금",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금증권전환형자투자신탁1호 (주식혼합)",
        "SeibroIsin":  "KRZ501698620",
        "Score":  1.3,
        "SecondName":  "미래에셋개인연금증권전환형자투자신탁1호(주식)",
        "SecondScore":  1.0262,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "61.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "20.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "2.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "25.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "17.12"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "두산에너빌리티",
                             "Weight":  "3.54"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK스퀘어",
                             "Weight":  "2.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "현대차",
                             "Weight":  "2.32"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "5.13"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03750-3312(13-8)",
                             "Weight":  "3.48"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03875-4309(23-9)",
                             "Weight":  "3.34"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고04000-3112(11-7)",
                             "Weight":  "2.88"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02625-3506(25-5)",
                             "Weight":  "2.74"
                         }
                     ],
        "CandidateCount":  26,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "7.03",
                      "PBR":  "1.68",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "4.86"
                  }
    },
    {
        "ExcelRow":  23,
        "Company":  "미래에셋자산운용",
        "Type":  "채권형",
        "FundName":  "미래에셋개인연금증권전환형투자신탁 1(채권)",
        "SearchTerm":  "미래에셋개인연금",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금증권전환형투자신탁1호(채권)",
        "SeibroIsin":  "KRZ500246950",
        "Score":  1.3,
        "SecondName":  "미래에셋개인연금증권전환형투자신탁1호(채권혼합)",
        "SecondScore":  1.0262,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "150.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "통안02840-2801-02",
                             "Weight":  "21.29"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02625-3003(25-3)",
                             "Weight":  "10.33"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01375-3006(20-4)",
                             "Weight":  "10.30"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-5409(24-8)",
                             "Weight":  "10.15"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고04125-3312(23-11)",
                             "Weight":  "8.85"
                         }
                     ],
        "CandidateCount":  26,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "5.68"
                  }
    },
    {
        "ExcelRow":  24,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합채권형",
        "FundName":  "미래에셋개인연금증권전환형투자신탁 1(채권혼합)",
        "SearchTerm":  "미래에셋개인연금",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금증권전환형투자신탁1호(채권혼합)",
        "SeibroIsin":  "KRZ500176800",
        "Score":  1.3,
        "SecondName":  "미래에셋개인연금증권전환형투자신탁1호(채권)",
        "SecondScore":  1.0262,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "28.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "51.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "22.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "27.61"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "15.78"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "한미반도체",
                             "Weight":  "2.72"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "두산에너빌리티",
                             "Weight":  "2.04"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "한화에어로스페이스",
                             "Weight":  "1.76"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "통안04000-2609-03",
                             "Weight":  "10.49"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "6.53"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국전력868",
                             "Weight":  "6.51"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "통안02700-2701-02",
                             "Weight":  "6.50"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "통안02620-2704-02",
                             "Weight":  "6.48"
                         }
                     ],
        "CandidateCount":  26,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "7.25",
                      "PBR":  "1.84",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.34"
                  }
    },
    {
        "ExcelRow":  25,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합채권형",
        "FundName":  "미래에셋개인연금코어밸류20증권전환형자투자신탁 1(채권혼합)",
        "SearchTerm":  "미래에셋개인연금코어밸류20",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금코어밸류20증권전환형자투자신탁1호(채권혼합)",
        "SeibroIsin":  "KRZ502020690",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "19.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "56.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "3.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "26.09"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "17.41"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "두산에너빌리티",
                             "Weight":  "3.06"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "후성",
                             "Weight":  "2.91"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "리가켐바이오",
                             "Weight":  "2.81"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02250-2806(25-4)",
                             "Weight":  "13.39"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "기업은행(신)2509할1A-18",
                             "Weight":  "11.23"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-2706(24-4)",
                             "Weight":  "10.36"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "기업은행(신)2411이1.5A-20",
                             "Weight":  "9.14"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2712(24-12)",
                             "Weight":  "9.11"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "8.62",
                      "PBR":  "2.44",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.19"
                  }
    },
    {
        "ExcelRow":  26,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합채권형",
        "FundName":  "미래에셋개인연금코어밸류40증권전환형자투자신탁 1(채권혼합)",
        "SearchTerm":  "미래에셋개인연금코어밸류40",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금코어밸류40증권전환형자투자신탁1호(채권혼합)",
        "SeibroIsin":  "KRZ502020700",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "38.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "43.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "3.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "26.09"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "17.41"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "두산에너빌리티",
                             "Weight":  "3.06"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "후성",
                             "Weight":  "2.91"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "리가켐바이오",
                             "Weight":  "2.81"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02250-2806(25-4)",
                             "Weight":  "13.39"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "기업은행(신)2509할1A-18",
                             "Weight":  "11.23"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-2706(24-4)",
                             "Weight":  "10.36"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "기업은행(신)2411이1.5A-20",
                             "Weight":  "9.14"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2712(24-12)",
                             "Weight":  "9.11"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "8.62",
                      "PBR":  "2.44",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.19"
                  }
    },
    {
        "ExcelRow":  27,
        "Company":  "미래에셋자산운용",
        "Type":  "재간접형",
        "FundName":  "미래에셋개인연금펀드솔루션40증권전환형자투자신탁 1(채권혼합-재간접형)",
        "SearchTerm":  "미래에셋개인연금펀드솔루션40",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금펀드솔루션40증권전환형자투자신탁1호(채권혼합-재간접형)",
        "SeibroIsin":  "KRZ502020890",
        "Score":  1.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "21.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "62.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "국고03125-2606(23-4)",
                             "Weight":  "26.02"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2609(24-9)",
                             "Weight":  "25.81"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "25.44"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02250-2806(25-4)",
                             "Weight":  "22.73"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.20"
                  }
    },
    {
        "ExcelRow":  28,
        "Company":  "미래에셋자산운용",
        "Type":  "혼합자산",
        "FundName":  "미래에셋개인연금평생소득TIF혼합자산자투자신탁",
        "SearchTerm":  "미래에셋개인연금평생소득TIF혼합자산자",
        "Status":  "matched",
        "MatchedName":  "미래에셋개인연금평생소득TIF혼합자산자투자신탁",
        "SeibroIsin":  "KRZ502314260",
        "Score":  1.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "12.00",
                           "OverseasStock":  "11.00",
                           "DomesticBond":  "13.00",
                           "OverseasBond":  "8.00",
                           "Fund":  "18.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "8.52"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "7.47"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "맥쿼리인프라",
                             "Weight":  "5.73"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "NVIDIA Corp",
                             "Weight":  "2.62"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자우",
                             "Weight":  "2.57"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2712(24-12)",
                             "Weight":  "5.56"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "T 3 1/2 01/31/28",
                             "Weight":  "3.28"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-3306(23-5)",
                             "Weight":  "2.40"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-2706(24-4)",
                             "Weight":  "2.30"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "2.24"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "6.96",
                      "PBR":  "2.01",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "4.11"
                  }
    },
    {
        "ExcelRow":  29,
        "Company":  "미래에셋자산운용",
        "Type":  "재간접형",
        "FundName":  "미래에셋하나1Q개인연금증권자투자신탁 1(주식혼합-재간접형)",
        "SearchTerm":  "미래에셋하나1Q개인연금",
        "Status":  "matched",
        "MatchedName":  "미래에셋하나1Q개인연금증권자투자신탁1호(주식혼합-재간접형)",
        "SeibroIsin":  "KRZ502053240",
        "Score":  1.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "60.00"
                       },
        "Holdings":  [

                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  30,
        "Company":  "삼성자산운용",
        "Type":  "재간접형",
        "FundName":  "삼성개인연금글로벌EMP적격TDF2030증권전환형자투자신탁[주식혼합-재간접형]",
        "SearchTerm":  "삼성개인연금글로벌EMP적격TDF2030",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  31,
        "Company":  "삼성자산운용",
        "Type":  "재간접형",
        "FundName":  "삼성개인연금글로벌EMP적격TDF2030증권전환형자투자신탁[주식혼합-재간접형]_C",
        "SearchTerm":  "삼성개인연금글로벌EMP적격TDF2030",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  32,
        "Company":  "삼성자산운용",
        "Type":  "재간접형",
        "FundName":  "삼성개인연금글로벌EMP적격TDF2050증권전환형자투자신탁[주식혼합-재간접형]",
        "SearchTerm":  "삼성개인연금글로벌EMP적격TDF2050",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  33,
        "Company":  "삼성자산운용",
        "Type":  "재간접형",
        "FundName":  "삼성개인연금글로벌EMP적격TDF2050증권전환형자투자신탁[주식혼합-재간접형]_C",
        "SearchTerm":  "삼성개인연금글로벌EMP적격TDF2050",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  34,
        "Company":  "삼성자산운용",
        "Type":  "주식형",
        "FundName":  "삼성개인연금미국S\u0026P500인덱스증권전환형자투자신탁H[주식]",
        "SearchTerm":  "삼성개인연금미국S\u0026P500인덱스",
        "Status":  "matched",
        "MatchedName":  "삼성개인연금미국S\u0026P500인덱스증권전환형자투자신탁H[주식]_C",
        "SeibroIsin":  "KRZ502491181",
        "Score":  1.13,
        "SecondName":  "삼성개인연금미국S\u0026P500인덱스증권전환형자투자신탁H[주식]_Ce",
        "SecondScore":  1.0848,
        "AsOf":  "",
        "Allocation":  {
                           "DomesticStock":  "",
                           "OverseasStock":  "",
                           "DomesticBond":  "",
                           "OverseasBond":  "",
                           "Fund":  ""
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "NVIDIA CORP",
                             "Weight":  "8.42"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "APPLE INC",
                             "Weight":  "6.53"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "MICROSOFT CORP",
                             "Weight":  "5.21"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "AMAZON.COM INC",
                             "Weight":  "4.25"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "ALPHABET INC-CL A",
                             "Weight":  "3.40"
                         }
                     ],
        "CandidateCount":  2,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  35,
        "Company":  "삼성자산운용",
        "Type":  "주식형",
        "FundName":  "삼성개인연금미국S\u0026P500인덱스증권전환형자투자신탁H[주식]_C",
        "SearchTerm":  "삼성개인연금미국S\u0026P500인덱스",
        "Status":  "matched",
        "MatchedName":  "삼성개인연금미국S\u0026P500인덱스증권전환형자투자신탁H[주식]_C",
        "SeibroIsin":  "KRZ502491181",
        "Score":  1.18,
        "SecondName":  "삼성개인연금미국S\u0026P500인덱스증권전환형자투자신탁H[주식]_Ce",
        "SecondScore":  1.1324,
        "AsOf":  "",
        "Allocation":  {
                           "DomesticStock":  "",
                           "OverseasStock":  "",
                           "DomesticBond":  "",
                           "OverseasBond":  "",
                           "Fund":  ""
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "NVIDIA CORP",
                             "Weight":  "8.42"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "APPLE INC",
                             "Weight":  "6.53"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "MICROSOFT CORP",
                             "Weight":  "5.21"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "AMAZON.COM INC",
                             "Weight":  "4.25"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "ALPHABET INC-CL A",
                             "Weight":  "3.40"
                         }
                     ],
        "CandidateCount":  2,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  36,
        "Company":  "삼성자산운용",
        "Type":  "주식형",
        "FundName":  "삼성개인연금미국S\u0026P500인덱스증권전환형자투자신탁H[주식]_Ce",
        "SearchTerm":  "삼성개인연금미국S\u0026P500인덱스",
        "Status":  "matched",
        "MatchedName":  "삼성개인연금미국S\u0026P500인덱스증권전환형자투자신탁H[주식]_Ce",
        "SeibroIsin":  "KRZ502491182",
        "Score":  1.18,
        "SecondName":  "삼성개인연금미국S\u0026P500인덱스증권전환형자투자신탁H[주식]_C",
        "SecondScore":  1.1324,
        "AsOf":  "",
        "Allocation":  {
                           "DomesticStock":  "",
                           "OverseasStock":  "",
                           "DomesticBond":  "",
                           "OverseasBond":  "",
                           "Fund":  ""
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "NVIDIA CORP",
                             "Weight":  "8.42"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "APPLE INC",
                             "Weight":  "6.53"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "MICROSOFT CORP",
                             "Weight":  "5.21"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "AMAZON.COM INC",
                             "Weight":  "4.25"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "ALPHABET INC-CL A",
                             "Weight":  "3.40"
                         }
                     ],
        "CandidateCount":  2,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  37,
        "Company":  "삼성자산운용",
        "Type":  "혼합채권형",
        "FundName":  "삼성개인연금주식 1",
        "SearchTerm":  "삼성개인연금주식 1",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  38,
        "Company":  "신영자산운용",
        "Type":  "혼합주식형",
        "FundName":  "신영신종개인연금60 증권 전환형 투자신탁(주식혼합)",
        "SearchTerm":  "신영신종개인연금60",
        "Status":  "matched",
        "MatchedName":  "신영신종개인연금60증권전환형투자신탁(주식혼합)",
        "SeibroIsin":  "KRZ500141380",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "57.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "37.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "27.93"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "19.04"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK스퀘어",
                             "Weight":  "5.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "HD현대중공업",
                             "Weight":  "3.71"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전기",
                             "Weight":  "3.30"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "인천도시공사206(사)",
                             "Weight":  "12.82"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "하나은행49-04이1.5갑-29",
                             "Weight":  "12.82"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "농업금융채권(은행)2024-11이2Y-C",
                             "Weight":  "11.20"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "서울교통공사2023-4",
                             "Weight":  "10.37"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "9.31"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "6.99",
                      "PBR":  "2.46",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.26"
                  }
    },
    {
        "ExcelRow":  39,
        "Company":  "신영자산운용",
        "Type":  "혼합주식형",
        "FundName":  "신영신종개인연금가치60증권전환형자투자신탁[주식혼합]",
        "SearchTerm":  "신영신종개인연금가치60",
        "Status":  "matched",
        "MatchedName":  "신영신종개인연금가치60증권전환형자투자신탁(주식혼합)",
        "SeibroIsin":  "KRZ500435080",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "57.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "23.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "2.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "24.51"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "16.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK스퀘어",
                             "Weight":  "5.52"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "HD현대중공업",
                             "Weight":  "4.18"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전기",
                             "Weight":  "3.48"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03875-4309(23-9)",
                             "Weight":  "16.12"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02000-3106(21-5)",
                             "Weight":  "7.43"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03500-3406(24-5)",
                             "Weight":  "5.29"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국가스공사327",
                             "Weight":  "3.73"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국전력1523",
                             "Weight":  "3.28"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "7.60",
                      "PBR":  "2.48",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "4.90"
                  }
    },
    {
        "ExcelRow":  40,
        "Company":  "신영자산운용",
        "Type":  "혼합주식형",
        "FundName":  "신영신종개인연금고배당인컴증권전환형자투자신탁(주식혼합)",
        "SearchTerm":  "신영신종개인연금고배당인컴",
        "Status":  "matched",
        "MatchedName":  "신영신종개인연금고배당인컴증권전환형자투자신탁(주식혼합)",
        "SeibroIsin":  "KRZ502530220",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "85.00",
                           "OverseasStock":  "12.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "HD현대",
                             "Weight":  "4.01"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK텔레콤",
                             "Weight":  "3.94"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "현대엘리베이터",
                             "Weight":  "3.87"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "NH투자증권",
                             "Weight":  "3.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "GS",
                             "Weight":  "3.66"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "CV",
                      "StockStyleLabel":  "멀티형/가치형",
                      "PER":  "7.84",
                      "PBR":  "0.96",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  41,
        "Company":  "신영자산운용",
        "Type":  "혼합주식형",
        "FundName":  "신영신종개인연금배당60증권전환형자투자신탁(주식혼합)",
        "SearchTerm":  "신영신종개인연금배당60",
        "Status":  "matched",
        "MatchedName":  "신영신종개인연금배당60증권전환형자투자신탁(주식혼합)",
        "SeibroIsin":  "KRZ501920470",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "57.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "24.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "2.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "12.37"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "10.59"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자우",
                             "Weight":  "6.26"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "현대차2우B",
                             "Weight":  "3.05"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "LS",
                             "Weight":  "2.80"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03875-4309(23-9)",
                             "Weight":  "16.12"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02000-3106(21-5)",
                             "Weight":  "7.43"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03500-3406(24-5)",
                             "Weight":  "5.29"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국가스공사327",
                             "Weight":  "3.73"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국전력1523",
                             "Weight":  "3.28"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "CB",
                      "StockStyleLabel":  "멀티형/혼합형",
                      "PER":  "7.26",
                      "PBR":  "1.31",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "4.90"
                  }
    },
    {
        "ExcelRow":  42,
        "Company":  "신영자산운용",
        "Type":  "채권형",
        "FundName":  "신영신종개인연금증권전환형투자신탁(채권)",
        "SearchTerm":  "신영신종개인연금",
        "Status":  "matched",
        "MatchedName":  "신영신종개인연금증권전환형투자신탁(채권)",
        "SeibroIsin":  "KRZ500017380",
        "Score":  1.3,
        "SecondName":  "신영신종개인연금60증권전환형투자신탁(주식혼합)",
        "SecondScore":  0.5714,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "89.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "인천도시공사228",
                             "Weight":  "16.91"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "경기주택도시공사24-11-85",
                             "Weight":  "16.69"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "경기주택도시공사23-09-61",
                             "Weight":  "11.86"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "인천국제공항공사191",
                             "Weight":  "10.09"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "우리은행29-11-이03-갑-13(녹)",
                             "Weight":  "9.90"
                         }
                     ],
        "CandidateCount":  5,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.58"
                  }
    },
    {
        "ExcelRow":  43,
        "Company":  "신한자산운용",
        "Type":  "혼합주식형",
        "FundName":  "신한신종개인연금증권자투자신탁 1[주식혼합]",
        "SearchTerm":  "신한신종개인연금",
        "Status":  "review",
        "MatchedName":  "신한신종개인연금증권자투자신탁제1호[주식혼합]",
        "SeibroIsin":  "KRZ500427790",
        "Score":  1.0486,
        "SecondName":  "신한신종개인연금증권자투자신탁제2호[주식혼합]",
        "SecondScore":  1.0431,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  3
    },
    {
        "ExcelRow":  44,
        "Company":  "신한자산운용",
        "Type":  "채권형",
        "FundName":  "신한신종개인연금증권자투자신탁 1[채권]",
        "SearchTerm":  "신한신종개인연금",
        "Status":  "matched",
        "MatchedName":  "신한신종개인연금증권자투자신탁제1호[채권]",
        "SeibroIsin":  "KRZ500587090",
        "Score":  0.9167,
        "SecondName":  "신한신종개인연금증권자투자신탁제1호[주식혼합]",
        "SecondScore":  0.6429,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "98.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "7.39"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02625-3003(25-3)",
                             "Weight":  "6.33"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03500-5603(26-2)",
                             "Weight":  "4.99"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "4.34"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "교보증권11-1",
                             "Weight":  "3.74"
                         }
                     ],
        "CandidateCount":  3,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "5.37"
                  }
    },
    {
        "ExcelRow":  45,
        "Company":  "신한자산운용",
        "Type":  "혼합주식형",
        "FundName":  "신한신종개인연금증권자투자신탁 2[주식혼합]",
        "SearchTerm":  "신한신종개인연금",
        "Status":  "matched",
        "MatchedName":  "신한신종개인연금증권자투자신탁제2호[주식혼합]",
        "SeibroIsin":  "KRZ500428720",
        "Score":  1.3,
        "SecondName":  "신한신종개인연금증권자투자신탁제1호[주식혼합]",
        "SecondScore":  0.9771,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "74.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "7.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "11.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "30.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "20.59"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "현대차",
                             "Weight":  "4.76"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "KB금융",
                             "Weight":  "3.38"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "한화에어로스페이스",
                             "Weight":  "3.06"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "7.39"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02625-3003(25-3)",
                             "Weight":  "6.33"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03500-5603(26-2)",
                             "Weight":  "4.99"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "4.34"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "교보증권11-1",
                             "Weight":  "3.74"
                         }
                     ],
        "CandidateCount":  3,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "6.29",
                      "PBR":  "2.10",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "5.37"
                  }
    },
    {
        "ExcelRow":  46,
        "Company":  "우리자산운용",
        "Type":  "채권형",
        "FundName":  "오리엔트파워신종개인연금채권투자신탁 1",
        "SearchTerm":  "오리엔트파워신종개인연금채권",
        "Status":  "matched",
        "MatchedName":  "오리엔트파워신종개인연금채권투자신탁1호",
        "SeibroIsin":  "KRZ500043590",
        "Score":  1.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "92.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "국민주택1종23-02",
                             "Weight":  "65.95"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03000-3412(24-13)",
                             "Weight":  "18.68"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02125-2706(17-3)",
                             "Weight":  "13.12"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02375-3809(18-7)",
                             "Weight":  "2.25"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "MH",
                      "BondStyleLabel":  "고등급/중기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "2.92"
                  }
    },
    {
        "ExcelRow":  47,
        "Company":  "우리자산운용",
        "Type":  "재간접형",
        "FundName":  "우리PIMCO글로벌투자등급자투자신탁[채권_재간접형](H)_ClassS(P)2",
        "SearchTerm":  "우리PIMCO글로벌투자등급자",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  48,
        "Company":  "우리자산운용",
        "Type":  "재간접형",
        "FundName":  "우리PIMCO토탈리턴증권자투자신탁[채권_재간접형](H)ClassS(P)2",
        "SearchTerm":  "우리PIMCO토탈리턴",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  49,
        "Company":  "우리자산운용",
        "Type":  "혼합주식형",
        "FundName":  "중앙개인연금 1주식혼합투자신탁",
        "SearchTerm":  "중앙개인연금 1주식혼합",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  50,
        "Company":  "케이비자산운용",
        "Type":  "재간접형",
        "FundName":  "KB개인연금단기자금증권자투자신탁(단기자금-재간접형)",
        "SearchTerm":  "KB개인연금단기자금",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  51,
        "Company":  "하나자산운용",
        "Type":  "채권형",
        "FundName":  "개인연금채권투자신탁S- 8",
        "SearchTerm":  "개인연금채권",
        "Status":  "matched",
        "MatchedName":  "개인연금채권 S- 8",
        "SeibroIsin":  "KRZ500048450",
        "Score":  1.18,
        "SecondName":  "개인연금채권 S- 5",
        "SecondScore":  0.875,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "82.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "4.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "한국투자캐피탈114-2",
                             "Weight":  "9.85"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02625-5503(25-2)",
                             "Weight":  "9.39"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한화시스템5-2",
                             "Weight":  "7.65"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "메리츠캐피탈259-3",
                             "Weight":  "7.62"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03000-3412(24-13)",
                             "Weight":  "7.40"
                         }
                     ],
        "CandidateCount":  10,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "6.20"
                  }
    },
    {
        "ExcelRow":  52,
        "Company":  "하나자산운용",
        "Type":  "혼합주식형",
        "FundName":  "개인연금혼합투자신탁S- 1",
        "SearchTerm":  "개인연금혼합",
        "Status":  "review",
        "MatchedName":  "Ｗ개인연금혼합 S- 1호",
        "SeibroIsin":  "KRZ500055510",
        "Score":  1.18,
        "SecondName":  "개인연금혼합 S- 1",
        "SecondScore":  1.18,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  21
    },
    {
        "ExcelRow":  53,
        "Company":  "하나자산운용",
        "Type":  "혼합주식형",
        "FundName":  "개인연금혼합투자신탁S- 2",
        "SearchTerm":  "개인연금혼합",
        "Status":  "matched",
        "MatchedName":  "개인연금혼합 S- 2",
        "SeibroIsin":  "KRZ500052620",
        "Score":  1.18,
        "SecondName":  "D개인연금혼합 S- 2",
        "SecondScore":  1.0689,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "53.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "28.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "5.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "29.66"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "19.70"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "OCI홀딩스",
                             "Weight":  "2.85"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전기",
                             "Weight":  "2.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "HD현대일렉트릭",
                             "Weight":  "2.44"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "산금25변이0100-1104-1M",
                             "Weight":  "11.75"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국캐피탈537-2",
                             "Weight":  "9.91"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "삼성카드2669",
                             "Weight":  "9.86"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "현대건설310-1(녹)",
                             "Weight":  "9.69"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "롯데캐피탈490-1",
                             "Weight":  "9.69"
                         }
                     ],
        "CandidateCount":  21,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "7.11",
                      "PBR":  "2.27",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.87"
                  }
    },
    {
        "ExcelRow":  54,
        "Company":  "하나자산운용",
        "Type":  "혼합주식형",
        "FundName":  "개인연금혼합투자신탁S- 3 ",
        "SearchTerm":  "개인연금혼합",
        "Status":  "matched",
        "MatchedName":  "개인연금혼합 S- 3",
        "SeibroIsin":  "KRZ500052630",
        "Score":  1.18,
        "SecondName":  "Ｗ개인연금혼합 S- 3호",
        "SecondScore":  1.0689,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "55.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "29.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "5.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "29.66"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "19.70"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "OCI홀딩스",
                             "Weight":  "2.85"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전기",
                             "Weight":  "2.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "HD현대일렉트릭",
                             "Weight":  "2.44"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "산금25변이0100-1104-1M",
                             "Weight":  "11.75"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국캐피탈537-2",
                             "Weight":  "9.91"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "삼성카드2669",
                             "Weight":  "9.86"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "현대건설310-1(녹)",
                             "Weight":  "9.69"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "롯데캐피탈490-1",
                             "Weight":  "9.69"
                         }
                     ],
        "CandidateCount":  21,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "7.11",
                      "PBR":  "2.27",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.87"
                  }
    },
    {
        "ExcelRow":  55,
        "Company":  "하나자산운용",
        "Type":  "혼합주식형",
        "FundName":  "개인연금혼합투자신탁S- 4",
        "SearchTerm":  "개인연금혼합",
        "Status":  "matched",
        "MatchedName":  "개인연금혼합 S- 4",
        "SeibroIsin":  "KRZ500052640",
        "Score":  1.18,
        "SecondName":  "D개인연금혼합 S- 4",
        "SecondScore":  1.0689,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "51.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "27.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "5.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "29.66"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "19.70"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "OCI홀딩스",
                             "Weight":  "2.85"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전기",
                             "Weight":  "2.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "HD현대일렉트릭",
                             "Weight":  "2.44"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "산금25변이0100-1104-1M",
                             "Weight":  "11.75"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국캐피탈537-2",
                             "Weight":  "9.91"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "삼성카드2669",
                             "Weight":  "9.86"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "현대건설310-1(녹)",
                             "Weight":  "9.69"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "롯데캐피탈490-1",
                             "Weight":  "9.69"
                         }
                     ],
        "CandidateCount":  21,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "7.11",
                      "PBR":  "2.27",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.87"
                  }
    },
    {
        "ExcelRow":  56,
        "Company":  "하나자산운용",
        "Type":  "혼합주식형",
        "FundName":  "개인연금혼합투자신탁S- 5",
        "SearchTerm":  "개인연금혼합",
        "Status":  "matched",
        "MatchedName":  "개인연금혼합 S- 5",
        "SeibroIsin":  "KRZ500052650",
        "Score":  1.18,
        "SecondName":  "D개인연금혼합 S- 5",
        "SecondScore":  1.0689,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "50.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "26.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "5.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "29.66"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "19.70"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "OCI홀딩스",
                             "Weight":  "2.85"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전기",
                             "Weight":  "2.68"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "HD현대일렉트릭",
                             "Weight":  "2.44"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "산금25변이0100-1104-1M",
                             "Weight":  "11.75"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국캐피탈537-2",
                             "Weight":  "9.91"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "삼성카드2669",
                             "Weight":  "9.86"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "현대건설310-1(녹)",
                             "Weight":  "9.69"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "롯데캐피탈490-1",
                             "Weight":  "9.69"
                         }
                     ],
        "CandidateCount":  21,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "7.11",
                      "PBR":  "2.27",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.87"
                  }
    },
    {
        "ExcelRow":  57,
        "Company":  "하나자산운용",
        "Type":  "혼합주식형",
        "FundName":  "뉴개인연금주식혼합S- 1",
        "SearchTerm":  "뉴개인연금주식혼합S- 1",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  58,
        "Company":  "하나자산운용",
        "Type":  "채권형",
        "FundName":  "뉴개인연금채권투자신탁S- 1",
        "SearchTerm":  "뉴개인연금채권",
        "Status":  "matched",
        "MatchedName":  "뉴개인연금채권S- 1호",
        "SeibroIsin":  "KRZ500048460",
        "Score":  1.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "89.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "4.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "국고02625-5503(25-2)",
                             "Weight":  "11.08"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국투자캐피탈114-2",
                             "Weight":  "10.14"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "메리츠캐피탈259-3",
                             "Weight":  "7.87"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한화시스템5-2",
                             "Weight":  "7.34"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "LG화학52-4",
                             "Weight":  "6.96"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "6.02"
                  }
    },
    {
        "ExcelRow":  59,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합주식형",
        "FundName":  "SE개인연금주식 1",
        "SearchTerm":  "SE개인연금주식 1",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  60,
        "Company":  "한국투자신탁운용",
        "Type":  "채권형",
        "FundName":  "개인연금공사채 7",
        "SearchTerm":  "개인연금공사채 7",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  61,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합주식형",
        "FundName":  "개인연금주식 1",
        "SearchTerm":  "개인연금주식 1",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  62,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합주식형",
        "FundName":  "개인연금주식 2",
        "SearchTerm":  "개인연금주식 2",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  63,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합주식형",
        "FundName":  "개인연금주식 3",
        "SearchTerm":  "개인연금주식 3",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  64,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합주식형",
        "FundName":  "개인연금주식 4",
        "SearchTerm":  "개인연금주식 4",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  65,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합주식형",
        "FundName":  "개인연금주식 5",
        "SearchTerm":  "개인연금주식 5",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  66,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합채권형",
        "FundName":  "파워코리아개인연금주식 6",
        "SearchTerm":  "파워코리아개인연금주식 6",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  67,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합주식형",
        "FundName":  "한국투자신종개인연금50증권전환형투자신탁 1(주식혼합)",
        "SearchTerm":  "한국투자신종개인연금50",
        "Status":  "matched",
        "MatchedName":  "한국투자신종개인연금50증권전환형투자신탁1호(주식혼합)",
        "SeibroIsin":  "KRZ500060230",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "48.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "36.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "2.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "24.46"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "17.16"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "두산에너빌리티",
                             "Weight":  "2.01"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "LG에너지솔루션",
                             "Weight":  "1.99"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "HD현대중공업",
                             "Weight":  "1.89"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "20.99"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국남부발전81-2",
                             "Weight":  "13.22"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국서부발전77-1",
                             "Weight":  "10.22"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "한국동서발전49-2",
                             "Weight":  "10.13"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "아이비케이캐피탈348-4",
                             "Weight":  "8.54"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "7.58",
                      "PBR":  "1.98",
                      "BondStyleCode":  "MH",
                      "BondStyleLabel":  "고등급/중기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "2.55"
                  }
    },
    {
        "ExcelRow":  68,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합주식형",
        "FundName":  "한국투자신종개인연금95증권전환형투자신탁 1(주식혼합)",
        "SearchTerm":  "한국투자신종개인연금95",
        "Status":  "matched",
        "MatchedName":  "한국투자신종개인연금95증권전환형투자신탁1호(주식혼합)",
        "SeibroIsin":  "KRZ500518600",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "92.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "4.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "26.04"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "15.73"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "LG에너지솔루션",
                             "Weight":  "2.13"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK스퀘어",
                             "Weight":  "2.11"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "두산에너빌리티",
                             "Weight":  "1.96"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LG",
                      "StockStyleLabel":  "대형/성장형",
                      "PER":  "7.60",
                      "PBR":  "1.98",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  69,
        "Company":  "한국투자신탁운용",
        "Type":  "재간접형",
        "FundName":  "한국투자신종개인연금TDF알아서2020증권자투자신탁(채권혼합-재간접형)",
        "SearchTerm":  "한국투자신종개인연금TDF알아서2020",
        "Status":  "matched",
        "MatchedName":  "한국투자신종개인연금TDF알아서2020증권전환형자투자신탁(채권혼합-재간접형) 종류 C",
        "SeibroIsin":  "KRZ502167391",
        "Score":  1.1455,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  {
                           "DomesticStock":  "",
                           "OverseasStock":  "",
                           "DomesticBond":  "",
                           "OverseasBond":  "",
                           "Fund":  ""
                       },
        "Holdings":  [

                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  70,
        "Company":  "한국투자신탁운용",
        "Type":  "재간접형",
        "FundName":  "한국투자신종개인연금TDF알아서2020증권자투자신탁(채권혼합-재간접형)(C)",
        "SearchTerm":  "한국투자신종개인연금TDF알아서2020",
        "Status":  "matched",
        "MatchedName":  "한국투자신종개인연금TDF알아서2020증권전환형자투자신탁(채권혼합-재간접형) 종류 C",
        "SeibroIsin":  "KRZ502167391",
        "Score":  1.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  {
                           "DomesticStock":  "",
                           "OverseasStock":  "",
                           "DomesticBond":  "",
                           "OverseasBond":  "",
                           "Fund":  ""
                       },
        "Holdings":  [

                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  71,
        "Company":  "한국투자신탁운용",
        "Type":  "재간접형",
        "FundName":  "한국투자신종개인연금TDF알아서2020증권전환형자투자신탁(채권혼합-재간접형)(C-e)",
        "SearchTerm":  "한국투자신종개인연금TDF알아서2020",
        "Status":  "matched",
        "MatchedName":  "한국투자신종개인연금TDF알아서2020증권전환형자투자신탁(채권혼합-재간접형) 종류 C",
        "SeibroIsin":  "KRZ502167391",
        "Score":  1.1467,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  {
                           "DomesticStock":  "",
                           "OverseasStock":  "",
                           "DomesticBond":  "",
                           "OverseasBond":  "",
                           "Fund":  ""
                       },
        "Holdings":  [

                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  72,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합주식형",
        "FundName":  "한국투자신종개인연금글로벌이머징증권전환형자투자신탁 1(주식혼합)",
        "SearchTerm":  "한국투자신종개인연금글로벌이머징",
        "Status":  "matched",
        "MatchedName":  "한국투자신종개인연금글로벌이머징증권전환형자투자신탁1호(주식혼합)",
        "SeibroIsin":  "KRZ500591940",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "22.00",
                           "OverseasStock":  "39.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "26.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "11.10"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "7.47"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "TAIWAN SEMICONDUCT",
                             "Weight":  "7.29"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "TENCENT HOLDINGS LTD-UNS ADR",
                             "Weight":  "5.03"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Alibaba Group Hold",
                             "Weight":  "3.70"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "6.74",
                      "PBR":  "2.03",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  73,
        "Company":  "한국투자신탁운용",
        "Type":  "주식형",
        "FundName":  "한국투자신종개인연금네비게이터중국본토증권전환형자투자신탁 2 H(주식)",
        "SearchTerm":  "한국투자신종개인연금네비게이터중국본토",
        "Status":  "matched",
        "MatchedName":  "한국투자신종개인연금네비게이터중국본토증권전환형자투자신탁2호H(주식)",
        "SeibroIsin":  "KRZ501906680",
        "Score":  1.0783,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "78.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "15.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "Contemporary Amperex Technology",
                             "Weight":  "6.58"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Zhongji Innolight Co Ltd",
                             "Weight":  "6.38"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "KWEICHOW MOUTAI CO LTD-A",
                             "Weight":  "5.38"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "WEICHAI POWER CO LTD-A",
                             "Weight":  "3.14"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "CHINA MERCHANTS BANK-A",
                             "Weight":  "3.12"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  74,
        "Company":  "한국투자신탁운용",
        "Type":  "혼합주식형",
        "FundName":  "한국투자신종개인연금브릭스증권전환형자투자신탁 1(주식혼합)",
        "SearchTerm":  "한국투자신종개인연금브릭스",
        "Status":  "matched",
        "MatchedName":  "한국투자신종개인연금브릭스증권전환형자투자신탁1호(주식혼합)",
        "SeibroIsin":  "KRZ500521090",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "63.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "23.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "TENCENT HOLDINGS LTD-UNS ADR",
                             "Weight":  "11.54"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "Alibaba Group Hold",
                             "Weight":  "8.48"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "CHINA CONSTRUCTION BANK-H",
                             "Weight":  "3.12"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "ICICI BANK ADR",
                             "Weight":  "3.09"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "JD.COM INC-ADR",
                             "Weight":  "2.83"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  75,
        "Company":  "한국투자신탁운용",
        "Type":  "재간접형",
        "FundName":  "한국투자신종개인연금적격TDF알아서2050증권전환형자투자신탁H(주식혼합-재간접형)(C)",
        "SearchTerm":  "한국투자신종개인연금적격TDF알아서2050",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  76,
        "Company":  "한국투자신탁운용",
        "Type":  "재간접형",
        "FundName":  "한국투자신종개인연금적격TDF알아서2050증권전환형자투자신탁H(주식혼합-재간접형)(C-e)",
        "SearchTerm":  "한국투자신종개인연금적격TDF알아서2050",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  77,
        "Company":  "한국투자신탁운용",
        "Type":  "재간접형",
        "FundName":  "한국투자신종개인연금적격TDF알아서2050증권전환형자투자신탁H(주식혼합-재간접형)(모)",
        "SearchTerm":  "한국투자신종개인연금적격TDF알아서2050",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  78,
        "Company":  "한국투자신탁운용",
        "Type":  "주식형",
        "FundName":  "한국투자신종개인연금중소밸류증권전환형자투자신탁(주식)",
        "SearchTerm":  "한국투자신종개인연금중소밸류",
        "Status":  "matched",
        "MatchedName":  "한국투자신종개인연금중소밸류증권전환형자투자신탁(주식)",
        "SeibroIsin":  "KRZ501891800",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "61.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "0.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "3.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "더블유게임즈",
                             "Weight":  "11.61"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "영원무역홀딩스",
                             "Weight":  "9.42"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "세아제강지주",
                             "Weight":  "8.60"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK가스",
                             "Weight":  "7.90"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "KSS해운",
                             "Weight":  "7.72"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "SV",
                      "StockStyleLabel":  "소형/가치형",
                      "PER":  "6.74",
                      "PBR":  "0.65",
                      "BondStyleCode":  "",
                      "BondStyleLabel":  "",
                      "BondCreditGrade":  "",
                      "BondAverageMaturity":  ""
                  }
    },
    {
        "ExcelRow":  79,
        "Company":  "한국투자신탁운용",
        "Type":  "채권형",
        "FundName":  "한국투자신종개인연금증권전환형투자신탁 1(채권)",
        "SearchTerm":  "한국투자신종개인연금",
        "Status":  "matched",
        "MatchedName":  "한국투자신종개인연금증권전환형투자신탁1호(채권)",
        "SeibroIsin":  "KRZ500059890",
        "Score":  1.3,
        "SecondName":  "한국투자신종개인연금50증권전환형투자신탁1호(주식혼합)",
        "SecondScore":  0.6471,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "88.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "2.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "한국서부발전77-1",
                             "Weight":  "10.57"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "도로공사1000",
                             "Weight":  "9.42"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "하나캐피탈473-4",
                             "Weight":  "9.34"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "메리츠캐피탈292-3",
                             "Weight":  "8.88"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "아이비케이캐피탈348-4",
                             "Weight":  "8.84"
                         }
                     ],
        "CandidateCount":  8,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "MH",
                      "BondStyleLabel":  "고등급/중기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "3.09"
                  }
    },
    {
        "ExcelRow":  80,
        "Company":  "한화자산운용",
        "Type":  "채권형",
        "FundName":  "H개인연금공사채투자신탁 2",
        "SearchTerm":  "H개인연금공사채",
        "Status":  "review",
        "MatchedName":  "H개인연금공사채투자신탁2호",
        "SeibroIsin":  "KRZ500038540",
        "Score":  1.08,
        "SecondName":  "H개인연금공사채투자신탁",
        "SecondScore":  1.0689,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  2
    },
    {
        "ExcelRow":  81,
        "Company":  "한화자산운용",
        "Type":  "혼합채권형",
        "FundName":  "한화개인연금골드혼합투자신탁",
        "SearchTerm":  "한화개인연금골드혼합",
        "Status":  "matched",
        "MatchedName":  "한화개인연금골드혼합투자신탁",
        "SeibroIsin":  "KRZ500038520",
        "Score":  1.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "42.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "21.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자우",
                             "Weight":  "37.90"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "11.28"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "4.00"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성SDI",
                             "Weight":  "3.78"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "LG에너지솔루션",
                             "Weight":  "3.55"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01875-2606(16-3)",
                             "Weight":  "30.78"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01375-3006(20-4)",
                             "Weight":  "23.79"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01375-2912(19-8)",
                             "Weight":  "21.27"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "11.64"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01500-3012(20-9)",
                             "Weight":  "5.56"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "7.08",
                      "PBR":  "2.59",
                      "BondStyleCode":  "MH",
                      "BondStyleLabel":  "고등급/중기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "3.30"
                  }
    },
    {
        "ExcelRow":  82,
        "Company":  "한화자산운용",
        "Type":  "채권형",
        "FundName":  "한화개인연금공사채투자신탁 3",
        "SearchTerm":  "한화개인연금공사채",
        "Status":  "matched",
        "MatchedName":  "한화개인연금공사채투자신탁3호",
        "SeibroIsin":  "KRZ500034530",
        "Score":  1.0891,
        "SecondName":  "한화개인연금공사채투자신탁1호",
        "SecondScore":  0.9,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "77.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2609(24-9)",
                             "Weight":  "27.68"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "27.27"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-2706(24-4)",
                             "Weight":  "13.97"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "경기주택도시공사25-07-108",
                             "Weight":  "13.77"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03875-2612(23-10)",
                             "Weight":  "12.66"
                         }
                     ],
        "CandidateCount":  6,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.32"
                  }
    },
    {
        "ExcelRow":  83,
        "Company":  "한화자산운용",
        "Type":  "채권형",
        "FundName":  "한화개인연금공사채투자신탁 4",
        "SearchTerm":  "한화개인연금공사채",
        "Status":  "matched",
        "MatchedName":  "한화개인연금공사채투자신탁4호",
        "SeibroIsin":  "KRZ500034560",
        "Score":  1.0891,
        "SecondName":  "한화개인연금공사채투자신탁1호",
        "SecondScore":  0.9,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "78.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2609(24-9)",
                             "Weight":  "27.68"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "27.27"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-2706(24-4)",
                             "Weight":  "13.97"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "경기주택도시공사25-07-108",
                             "Weight":  "13.77"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03875-2612(23-10)",
                             "Weight":  "12.66"
                         }
                     ],
        "CandidateCount":  6,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.32"
                  }
    },
    {
        "ExcelRow":  84,
        "Company":  "한화자산운용",
        "Type":  "채권형",
        "FundName":  "한화개인연금공사채투자신탁 5",
        "SearchTerm":  "한화개인연금공사채",
        "Status":  "matched",
        "MatchedName":  "한화개인연금공사채투자신탁5호",
        "SeibroIsin":  "KRZ500034730",
        "Score":  1.0891,
        "SecondName":  "한화개인연금공사채투자신탁50호",
        "SecondScore":  1.0133,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "78.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2609(24-9)",
                             "Weight":  "27.68"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "27.27"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-2706(24-4)",
                             "Weight":  "13.97"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "경기주택도시공사25-07-108",
                             "Weight":  "13.77"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03875-2612(23-10)",
                             "Weight":  "12.66"
                         }
                     ],
        "CandidateCount":  6,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.32"
                  }
    },
    {
        "ExcelRow":  85,
        "Company":  "한화자산운용",
        "Type":  "채권형",
        "FundName":  "한화개인연금공사채투자신탁50",
        "SearchTerm":  "한화개인연금공사채",
        "Status":  "matched",
        "MatchedName":  "한화개인연금공사채투자신탁50호",
        "SeibroIsin":  "KRZ500034580",
        "Score":  1.0967,
        "SecondName":  "한화개인연금공사채투자신탁5호",
        "SecondScore":  0.9091,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "78.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2609(24-9)",
                             "Weight":  "27.68"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02750-2812(25-10)",
                             "Weight":  "27.27"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03250-2706(24-4)",
                             "Weight":  "13.97"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "경기주택도시공사25-07-108",
                             "Weight":  "13.77"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고03875-2612(23-10)",
                             "Weight":  "12.66"
                         }
                     ],
        "CandidateCount":  6,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.32"
                  }
    },
    {
        "ExcelRow":  86,
        "Company":  "한화자산운용",
        "Type":  "혼합채권형",
        "FundName":  "한화개인연금혼합투자신탁 1",
        "SearchTerm":  "한화개인연금혼합",
        "Status":  "matched",
        "MatchedName":  "한화개인연금혼합투자신탁1호",
        "SeibroIsin":  "KRZ500034430",
        "Score":  1.18,
        "SecondName":  "한화개인연금혼합투자신탁3호",
        "SecondScore":  0.8,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "50.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "25.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자우",
                             "Weight":  "37.90"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "11.28"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "4.00"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성SDI",
                             "Weight":  "3.78"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "LG에너지솔루션",
                             "Weight":  "3.55"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01875-2606(16-3)",
                             "Weight":  "30.78"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01375-3006(20-4)",
                             "Weight":  "23.79"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01375-2912(19-8)",
                             "Weight":  "21.27"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "11.64"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01500-3012(20-9)",
                             "Weight":  "5.56"
                         }
                     ],
        "CandidateCount":  3,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "7.08",
                      "PBR":  "2.59",
                      "BondStyleCode":  "MH",
                      "BondStyleLabel":  "고등급/중기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "3.30"
                  }
    },
    {
        "ExcelRow":  87,
        "Company":  "한화자산운용",
        "Type":  "혼합채권형",
        "FundName":  "한화개인연금혼합투자신탁 2",
        "SearchTerm":  "한화개인연금혼합",
        "Status":  "matched",
        "MatchedName":  "한화개인연금혼합투자신탁2호",
        "SeibroIsin":  "KRZ500034440",
        "Score":  1.08,
        "SecondName":  "한화개인연금혼합투자신탁1호",
        "SecondScore":  0.8889,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "56.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "28.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자우",
                             "Weight":  "37.90"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "11.28"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "4.00"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성SDI",
                             "Weight":  "3.78"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "LG에너지솔루션",
                             "Weight":  "3.55"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01875-2606(16-3)",
                             "Weight":  "30.78"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01375-3006(20-4)",
                             "Weight":  "23.79"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01375-2912(19-8)",
                             "Weight":  "21.27"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02500-3009(25-8)",
                             "Weight":  "11.64"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01500-3012(20-9)",
                             "Weight":  "5.56"
                         }
                     ],
        "CandidateCount":  3,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "7.08",
                      "PBR":  "2.59",
                      "BondStyleCode":  "MH",
                      "BondStyleLabel":  "고등급/중기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "3.30"
                  }
    },
    {
        "ExcelRow":  88,
        "Company":  "한화자산운용",
        "Type":  "혼합채권형",
        "FundName":  "한화개인연금혼합투자신탁 3",
        "SearchTerm":  "한화개인연금혼합",
        "Status":  "matched",
        "MatchedName":  "한화개인연금혼합투자신탁3호",
        "SeibroIsin":  "KRZ500035050",
        "Score":  1.08,
        "SecondName":  "한화개인연금혼합투자신탁1호",
        "SecondScore":  0.8889,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "49.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "47.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "26.84"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "19.57"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "LG에너지솔루션",
                             "Weight":  "2.58"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "HD현대일렉트릭",
                             "Weight":  "2.01"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전기",
                             "Weight":  "2.00"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02875-2609(24-9)",
                             "Weight":  "100.00"
                         }
                     ],
        "CandidateCount":  3,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "6.92",
                      "PBR":  "1.82",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "0.35"
                  }
    },
    {
        "ExcelRow":  89,
        "Company":  "한화자산운용",
        "Type":  "혼합채권형",
        "FundName":  "한화신종개인연금50증권전환형투자신탁SL 1[채권혼합]",
        "SearchTerm":  "한화신종개인연금50",
        "Status":  "matched",
        "MatchedName":  "한화신종개인연금50증권전환형투자신탁SL1호(채권혼합)",
        "SeibroIsin":  "KRZ500036320",
        "Score":  1.3,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "49.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "18.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "0.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전자",
                             "Weight":  "27.12"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK하이닉스",
                             "Weight":  "19.02"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "LG에너지솔루션",
                             "Weight":  "2.59"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "SK스퀘어",
                             "Weight":  "1.81"
                         },
                         {
                             "Kind":  "stock",
                             "Name":  "삼성전기",
                             "Weight":  "1.63"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01500-3012(20-9)",
                             "Weight":  "40.49"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01375-2912(19-8)",
                             "Weight":  "21.10"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01875-2606(16-3)",
                             "Weight":  "19.50"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고02250-3709(17-5)",
                             "Weight":  "8.26"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "국고01375-3006(20-4)",
                             "Weight":  "7.53"
                         }
                     ],
        "CandidateCount":  1,
        "Style":  {
                      "StockStyleCode":  "LB",
                      "StockStyleLabel":  "대형/혼합형",
                      "PER":  "6.90",
                      "PBR":  "1.80",
                      "BondStyleCode":  "LH",
                      "BondStyleLabel":  "고등급/장기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "4.19"
                  }
    },
    {
        "ExcelRow":  90,
        "Company":  "한화자산운용",
        "Type":  "재간접형",
        "FundName":  "한화신종개인연금TDF2020증권전환형자투자신탁(채권혼합-재간접형)",
        "SearchTerm":  "한화신종개인연금TDF2020",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  91,
        "Company":  "한화자산운용",
        "Type":  "재간접형",
        "FundName":  "한화신종개인연금적격TDF2025증권전환형자투자신탁(채권혼합-재간접형)",
        "SearchTerm":  "한화신종개인연금적격TDF2025",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  92,
        "Company":  "한화자산운용",
        "Type":  "재간접형",
        "FundName":  "한화신종개인연금적격TDF2030증권전환형자투자신탁(혼합-재간접형)",
        "SearchTerm":  "한화신종개인연금적격TDF2030",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  93,
        "Company":  "한화자산운용",
        "Type":  "재간접형",
        "FundName":  "한화신종개인연금적격TDF2040증권전환형자투자신탁(주식혼합-재간접형)",
        "SearchTerm":  "한화신종개인연금적격TDF2040",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  94,
        "Company":  "한화자산운용",
        "Type":  "재간접형",
        "FundName":  "한화신종개인연금적격TDF2050증권전환형자투자신탁(주식혼합-재간접형)",
        "SearchTerm":  "한화신종개인연금적격TDF2050",
        "Status":  "review",
        "MatchedName":  "",
        "SeibroIsin":  "",
        "Score":  0.18,
        "SecondName":  "",
        "SecondScore":  0,
        "AsOf":  "",
        "Allocation":  null,
        "Holdings":  [

                     ],
        "CandidateCount":  1
    },
    {
        "ExcelRow":  95,
        "Company":  "한화자산운용",
        "Type":  "채권형",
        "FundName":  "한화신종개인연금증권전환형자투자신탁(채권)",
        "SearchTerm":  "한화신종개인연금",
        "Status":  "matched",
        "MatchedName":  "한화신종개인연금증권전환형 자투자신탁(채권)",
        "SeibroIsin":  "KRZ500035910",
        "Score":  1.3,
        "SecondName":  "한화신종개인연금50증권전환형투자신탁SL1호(채권혼합)",
        "SecondScore":  0.5882,
        "AsOf":  "기준일 : 2026/07/03",
        "Allocation":  {
                           "DomesticStock":  "0.00",
                           "OverseasStock":  "0.00",
                           "DomesticBond":  "54.00",
                           "OverseasBond":  "0.00",
                           "Fund":  "2.00"
                       },
        "Holdings":  [
                         {
                             "Kind":  "bond",
                             "Name":  "전자단기사채(모멘텀제일차 20260220-89-1(단))",
                             "Weight":  "8.61"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "롯데캐피탈460-4",
                             "Weight":  "4.37"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "코오롱인더스트리65-2",
                             "Weight":  "4.36"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "E139-2",
                             "Weight":  "4.35"
                         },
                         {
                             "Kind":  "bond",
                             "Name":  "롯데카드536-2",
                             "Weight":  "4.33"
                         }
                     ],
        "CandidateCount":  2,
        "Style":  {
                      "StockStyleCode":  "",
                      "StockStyleLabel":  "",
                      "PER":  "",
                      "PBR":  "",
                      "BondStyleCode":  "SH",
                      "BondStyleLabel":  "고등급/단기형",
                      "BondCreditGrade":  "AAA",
                      "BondAverageMaturity":  "1.74"
                  }
    }
];